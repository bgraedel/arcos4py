{%
  include-markdown "../CONTRIBUTING.md"
%}
